# MedGuard AI Website Dashboard — Admin Panel Update

This is the next local hackathon prototype stage. It adds a demo Admin Panel to the existing Flask + SQLite website, while preserving the doctor dashboard and server-side patient assignment checks. **ThingSpeak is intentionally not connected in this update**; it is planned for the next stage.

## Features in this update

- Demo admin sign-in and protected `/admin` page.
- Doctor signups are marked **pending** and cannot sign in until an admin approves them.
- Admin can approve or block/revoke doctor accounts.
- Admin can create synthetic demo patient placeholders.
- Admin can assign or remove a patient-to-doctor relationship through server endpoints.
- Only approved, non-admin doctor accounts can receive assignments.
- Doctor patient-list and record endpoints check the signed-in doctor's assignment on the server. A doctor cannot gain access by editing browser code or guessing a patient ID.
- Audit events record signup, login, approval, assignment, unassignment, patient creation, and patient-record access attempts.
- Existing local SQLite databases are upgraded automatically with admin/approval columns. Existing demo doctors remain approved; new signups are pending.
- No ThingSpeak API key or channel credential is used in this stage.

## Requirements

- Python 3.10 or newer
- VS Code (recommended)
- Internet is not required after Flask is installed

## Run in VS Code — Windows PowerShell

1. Extract the ZIP file.
2. Open the extracted `MedGuardAI_Website_Dashboard` folder in VS Code.
3. Select **Terminal → New Terminal**.
4. Install dependencies:

   ```powershell
   python -m pip install -r requirements.txt
   ```

5. Set a local secret key in that same terminal. Use a different long random value for your own machine:

   ```powershell
   $env:MEDGUARD_SECRET_KEY = "replace-with-a-long-random-secret-for-local-demo"
   ```

6. Optional but recommended: change the demo admin credentials before the first run. If this database already contains an `admin` account, changing these variables will **not** reset its password; use a fresh local demo database or update the account deliberately.

   ```powershell
   $env:MEDGUARD_DEMO_ADMIN_USERNAME = "admin"
   $env:MEDGUARD_DEMO_ADMIN_PASSWORD = "use-a-unique-long-demo-password"
   ```

7. Start the server:

   ```powershell
   python app.py
   ```

8. Open `http://127.0.0.1:5000` in your browser. Keep the terminal running while you use the site.

## macOS / Linux

```bash
python3 -m pip install -r requirements.txt
export MEDGUARD_SECRET_KEY="replace-with-a-long-random-secret-for-local-demo"
export MEDGUARD_DEMO_ADMIN_USERNAME="admin"
export MEDGUARD_DEMO_ADMIN_PASSWORD="use-a-unique-long-demo-password"
python3 app.py
```

Then open `http://127.0.0.1:5000`.

## Demo login accounts

Default credentials on a fresh database:

- **Admin:** `admin` / `Admin-MedGuard-Demo!`
- **Doctor 1:** `doctor1` / `Demo-Doctor1-ChangeMe!` — assigned to Patient 101
- **Doctor 2:** `doctor2` / `Demo-Doctor2-ChangeMe!` — assigned to Patient 102

These are intentionally easy-to-present demo credentials. **Do not deploy them or use them with real patient data.** For a fresh database with your own admin password, set `MEDGUARD_DB_PATH` to a new filename before the first launch, for example `$env:MEDGUARD_DB_PATH = "medguard_demo_fresh.db"` in PowerShell.

## Suggested hackathon demo flow

1. Sign in as `admin` and open the Admin Panel.
2. Register a new doctor using **Create an account** in a private/incognito window.
3. Show that the new doctor cannot sign in until approved.
4. Return to Admin Panel and approve the new account.
5. Assign Patient 101 or 102 to the approved doctor.
6. Sign in as that doctor and show that only assigned patients are listed.
7. Try accessing the other patient's `/patients/<id>/records` route from that doctor's session; the server should return `403 Access denied` and record a denied audit event.
8. Return to Admin Panel to show the audit log.

## Useful routes

- `/` — sign-in / doctor dashboard
- `/signup` — doctor registration
- `/admin` — admin-only panel
- `/health` — local backend health check

Admin API routes are protected on the server. Do not treat hiding a UI control as access control; the route authorization checks are the actual protection.

## Important limitations

- Demo only. Uses synthetic sample vitals and a local SQLite database.
- ESP32 hardware is not connected yet. ThingSpeak integration reads the latest channel feed and displays all eight fields; this prototype does not provide clinical alert validation, independent tamper detection, notifications, MFA, CSRF protection, rate limiting, or production deployment hardening.
- The admin credentials are seeded for a local hackathon demo. Do not expose the development server to the public internet.
- Before any real healthcare deployment, add HTTPS, CSRF protection, MFA, rate limiting, robust account recovery, secure secret management, independent security review, clinical validation, and privacy/legal review. Never use real patient data in this prototype.

## Next update

Connect ThingSpeak through the **Flask backend**, using a private channel and a server-side read key. Browser JavaScript should call the MedGuard API and must never receive ThingSpeak API keys. Map the channel's Field 1 / Field 2 / Field 3 to heart rate / SpO₂ / temperature only after confirming the ESP32 upload mapping.


## ThingSpeak live integration (one demo patient)

This version reads the latest ThingSpeak feed on the Flask server and displays all eight configured fields in the doctor dashboard. It does **not** expose the ThingSpeak read API key to browser JavaScript. The configured channel is mapped to exactly one local patient using `THINGSPEAK_PATIENT_ID` (defaults to patient `101`). The server checks that the signed-in doctor is assigned to that patient before fetching or returning readings. The patient-record endpoint also performs a server-side assignment check.

### ThingSpeak field mapping (all 8 fields)

- Field 1: Heart rate in BPM
- Field 2: SpO2 in percent
- Field 3: Temperature in Celsius
- Field 4: Sequence number
- Field 5: Health status code (`0` Normal, `1` Warning, `2` Critical, `-1` Unknown)
- Field 6: Reported security status code (`0` OK, `1` Suspicious, `2` Integrity failure)
- Field 7: Sensor quality code (`0` Good, `1` Poor, `2` Sensor error)
- Field 8: Network status code (`0` Online, `1` Offline/buffered, `2` Reconnecting)

These are proposed MedGuard AI demo codes, not ThingSpeak standards. The dashboard displays them as reported values; they do not independently prove tampering, sensor accuracy, or clinical status. Fields 4-8 may be blank during setup and will display as unknown. Fields 1-3 must be numeric and within the demo input-validation limits.

Create a ThingSpeak channel at https://thingspeak.mathworks.com/ and enable those three fields. Copy the **Channel ID** and **Read API Key** (for a private channel) from the channel's API Keys page. Keep the read key private.

### Configure on Windows PowerShell

Run these in the same terminal **before** `python app.py` (replace the example values):

```powershell
$env:MEDGUARD_SECRET_KEY = "replace-with-a-long-random-secret"
$env:THINGSPEAK_CHANNEL_ID = "YOUR_CHANNEL_ID"
$env:THINGSPEAK_READ_API_KEY = "YOUR_READ_API_KEY"
$env:THINGSPEAK_PATIENT_ID = "101"
python app.py
```

If the channel is public, `THINGSPEAK_READ_API_KEY` can be left unset; using a private channel is recommended. Ensure Patient 101 exists and the signed-in doctor is assigned to Patient 101. For another patient, change `THINGSPEAK_PATIENT_ID` to that patient's ID and restart Flask. This demo supports one configured channel-to-patient mapping at a time.

The dashboard refreshes at 20-second intervals to respect ThingSpeak's typical free-channel update interval. You can also press **Refresh** manually. Readings are stored as `source=thingspeak` in the local SQLite database, deduplicated by patient and measurement timestamp. If no new feed exists, check that your ESP32 is publishing values and that the field mapping is correct.

### ESP32 / simulated sender upload format

The sender should publish numeric values to ThingSpeak Fields 1–8 in the mapping above. Fields 1–3 are required for the vital-sign cards; fields 4–8 may be left blank while setting up, and will show as unknown. Do not put the ThingSpeak **Write API Key** into this website or dashboard JavaScript; the ESP32 uses it to upload data, while this website uses the server-side Read API Key to retrieve data. Never commit API keys or real patient information to Git or share them in screenshots.

### Troubleshooting

- `Not configured`: set `THINGSPEAK_CHANNEL_ID` in the same terminal and restart Flask.
- `ThingSpeak rejected the channel/read API key`: verify the channel ID and read key.
- `No ThingSpeak feed is available yet`: publish at least one entry from the ESP32 or ThingSpeak test interface.
- `Access denied`: use a doctor account assigned to the configured patient, or change the configured patient ID.
- `outside the demo validation limits`: check field order and units; the demo expects HR 20–250 BPM, SpO2 50–100%, temperature 25–45 °C. These are input-validation limits, not clinical alert thresholds.

**Prototype only:** this is not a medical device or a substitute for clinical monitoring. Do not use it for real patient care without a security, privacy, reliability, and clinical safety review.
