import os
import re
import sqlite3
import json
import math
import urllib.parse
import urllib.request
import urllib.error
from functools import wraps
from datetime import datetime, timezone

from flask import Flask, jsonify, request, session, g, render_template, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash

APP_SECRET = os.environ.get("MEDGUARD_SECRET_KEY")
if not APP_SECRET:
    raise RuntimeError(
        "Set MEDGUARD_SECRET_KEY before starting the server. "
        "Use a long, random secret; do not commit it to source control."
    )

DB_PATH = os.environ.get("MEDGUARD_DB_PATH", "medguard.db")
ADMIN_USERNAME = os.environ.get("MEDGUARD_DEMO_ADMIN_USERNAME", "admin")
ADMIN_PASSWORD = os.environ.get("MEDGUARD_DEMO_ADMIN_PASSWORD", "Admin-MedGuard-Demo!")
THINGSPEAK_CHANNEL_ID = os.environ.get("THINGSPEAK_CHANNEL_ID", "").strip()
THINGSPEAK_READ_API_KEY = os.environ.get("THINGSPEAK_READ_API_KEY", "").strip()
THINGSPEAK_PATIENT_ID_RAW = os.environ.get("THINGSPEAK_PATIENT_ID", "101").strip()
try:
    THINGSPEAK_PATIENT_ID = int(THINGSPEAK_PATIENT_ID_RAW)
except ValueError:
    THINGSPEAK_PATIENT_ID = 101
app = Flask(__name__)
app.config.update(
    SECRET_KEY=APP_SECRET,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("MEDGUARD_HTTPS", "0") == "1",
    PERMANENT_SESSION_LIFETIME=1800,
    MAX_CONTENT_LENGTH=1024 * 1024,
)


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_error=None):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS doctors (
        id INTEGER PRIMARY KEY,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        is_admin INTEGER NOT NULL DEFAULT 0,
        is_approved INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE IF NOT EXISTS patients (
        id INTEGER PRIMARY KEY,
        display_name TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS assignments (
        doctor_id INTEGER NOT NULL REFERENCES doctors(id),
        patient_id INTEGER NOT NULL REFERENCES patients(id),
        PRIMARY KEY (doctor_id, patient_id)
    );
    CREATE TABLE IF NOT EXISTS vital_readings (
        id INTEGER PRIMARY KEY,
        patient_id INTEGER NOT NULL REFERENCES patients(id),
        heart_rate_bpm INTEGER NOT NULL,
        spo2_percent REAL NOT NULL,
        temperature_c REAL NOT NULL,
        measured_at TEXT NOT NULL,
        source TEXT NOT NULL DEFAULT 'synthetic_demo'
    );
    CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY,
        occurred_at TEXT NOT NULL,
        actor_doctor_id INTEGER,
        patient_id INTEGER,
        action TEXT NOT NULL,
        outcome TEXT NOT NULL,
        detail TEXT NOT NULL
    );
    """)
    # Upgrade databases created by the earlier signup-only version.
    cols = {row[1] for row in conn.execute("PRAGMA table_info(doctors)").fetchall()}
    if "is_admin" not in cols:
        conn.execute("ALTER TABLE doctors ADD COLUMN is_admin INTEGER NOT NULL DEFAULT 0")
    if "is_approved" not in cols:
        # Existing demo doctors remain usable; new signups are explicitly pending.
        conn.execute("ALTER TABLE doctors ADD COLUMN is_approved INTEGER NOT NULL DEFAULT 1")
    conn.commit()
    conn.close()


def seed_demo_data():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")
    # Demo admin is created only if absent. Override credentials through environment variables.
    admin = conn.execute("SELECT id FROM doctors WHERE username=?", (ADMIN_USERNAME,)).fetchone()
    if admin is None:
        conn.execute(
            "INSERT INTO doctors (username, password_hash, is_admin, is_approved) VALUES (?, ?, 1, 1)",
            (ADMIN_USERNAME, generate_password_hash(ADMIN_PASSWORD)),
        )

    for username, password in [
        ("doctor1", "Demo-Doctor1-ChangeMe!"),
        ("doctor2", "Demo-Doctor2-ChangeMe!"),
    ]:
        exists = conn.execute("SELECT id FROM doctors WHERE username=?", (username,)).fetchone()
        if exists is None:
            conn.execute(
                "INSERT INTO doctors (username, password_hash, is_admin, is_approved) VALUES (?, ?, 0, 1)",
                (username, generate_password_hash(password)),
            )

    for patient_id, name in [(101, "Demo Patient A"), (102, "Demo Patient B")]:
        conn.execute("INSERT OR IGNORE INTO patients (id, display_name) VALUES (?, ?)", (patient_id, name))

    doctor1 = conn.execute("SELECT id FROM doctors WHERE username='doctor1'").fetchone()
    doctor2 = conn.execute("SELECT id FROM doctors WHERE username='doctor2'").fetchone()
    if doctor1:
        conn.execute("INSERT OR IGNORE INTO assignments (doctor_id, patient_id) VALUES (?, 101)", (doctor1[0],))
    if doctor2:
        conn.execute("INSERT OR IGNORE INTO assignments (doctor_id, patient_id) VALUES (?, 102)", (doctor2[0],))

    for patient_id, hr, spo2, temp in [(101, 76, 98.0, 36.8), (102, 82, 97.0, 36.7)]:
        exists = conn.execute("SELECT id FROM vital_readings WHERE patient_id=? LIMIT 1", (patient_id,)).fetchone()
        if exists is None:
            conn.execute("""INSERT INTO vital_readings
                (patient_id, heart_rate_bpm, spo2_percent, temperature_c, measured_at, source)
                VALUES (?, ?, ?, ?, ?, ?)""",
                (patient_id, hr, spo2, temp, utc_now(), "synthetic_demo"))
    conn.commit()
    conn.close()



def fetch_thingspeak_latest():
    """Fetch one latest feed from ThingSpeak; credentials remain server-side."""
    if not THINGSPEAK_CHANNEL_ID:
        raise RuntimeError("ThingSpeak is not configured. Set THINGSPEAK_CHANNEL_ID in your terminal.")
    if not THINGSPEAK_CHANNEL_ID.isdigit():
        raise RuntimeError("THINGSPEAK_CHANNEL_ID must contain digits only.")
    query = {"results": 1}
    if THINGSPEAK_READ_API_KEY:
        query["api_key"] = THINGSPEAK_READ_API_KEY
    url = f"https://api.thingspeak.com/channels/{THINGSPEAK_CHANNEL_ID}/feeds/last.json?{urllib.parse.urlencode(query)}"
    req = urllib.request.Request(url, headers={"Accept": "application/json", "User-Agent": "MedGuardAI-Demo/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=8) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        if exc.code in (401, 403):
            raise RuntimeError("ThingSpeak rejected the channel/read API key. Check your settings.") from exc
        raise RuntimeError(f"ThingSpeak returned HTTP {exc.code}.") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError("Could not reach ThingSpeak. Check your internet connection and channel settings.") from exc
    except (TimeoutError, json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise RuntimeError("ThingSpeak response was unavailable or invalid.") from exc

    # ThingSpeak may return an error string instead of feed data for a bad channel/key.
    if not isinstance(payload, dict) or not payload.get("created_at"):
        message = payload.get("error") if isinstance(payload, dict) else None
        raise RuntimeError(str(message or "No ThingSpeak feed is available yet. Send a sensor update first."))

    def numeric(field_name):
        raw = payload.get(field_name)
        try:
            value = float(raw)
        except (TypeError, ValueError):
            raise RuntimeError(f"ThingSpeak {field_name} is missing or not numeric.")
        if not math.isfinite(value):
            raise RuntimeError(f"ThingSpeak {field_name} is not a valid number.")
        return value

    hr = numeric("field1")
    spo2 = numeric("field2")
    temperature = numeric("field3")
    if not (20 <= hr <= 250 and 50 <= spo2 <= 100 and 25 <= temperature <= 45):
        raise RuntimeError("The latest ThingSpeak reading is outside the demo validation limits; check your field mapping and sensor data.")

    # Fields 4-8 are optional during setup; absent values are reported as unknown.
    def optional_code(field_name):
        raw = payload.get(field_name)
        if raw in (None, ""):
            return None
        try:
            value = float(raw)
        except (TypeError, ValueError):
            return None
        if not math.isfinite(value) or not value.is_integer():
            return None
        return int(value)

    health_codes = {0: "Normal", 1: "Warning", 2: "Critical", -1: "Unknown"}
    security_codes = {0: "OK", 1: "Suspicious", 2: "Integrity failure"}
    sensor_codes = {0: "Good", 1: "Poor", 2: "Sensor error"}
    network_codes = {0: "Online", 1: "Offline / buffered", 2: "Reconnecting"}
    sequence = optional_code("field4")
    health = optional_code("field5")
    security = optional_code("field6")
    sensor = optional_code("field7")
    network = optional_code("field8")
    return {
        "heart_rate_bpm": int(round(hr)),
        "spo2_percent": round(spo2, 1),
        "temperature_c": round(temperature, 2),
        "sequence_number": sequence,
        "health_status_code": health,
        "health_status_label": health_codes.get(health, "Unknown / unmapped"),
        "security_status_code": security,
        "security_status_label": security_codes.get(security, "Unknown / unmapped"),
        "sensor_quality_code": sensor,
        "sensor_quality_label": sensor_codes.get(sensor, "Unknown / unmapped"),
        "network_status_code": network,
        "network_status_label": network_codes.get(network, "Unknown / unmapped"),
        "measured_at": payload["created_at"],
        "source": "thingspeak",
        "entry_id": payload.get("entry_id"),
    }


def write_audit(actor_id, patient_id, action, outcome, detail):
    db().execute("""INSERT INTO audit_log
        (occurred_at, actor_doctor_id, patient_id, action, outcome, detail)
        VALUES (?, ?, ?, ?, ?, ?)""",
        (utc_now(), actor_id, patient_id, action, outcome, detail[:300]))
    db().commit()


def current_user():
    user_id = session.get("doctor_id")
    if not user_id:
        return None
    return db().execute(
        "SELECT id, username, is_admin, is_approved FROM doctors WHERE id=?", (user_id,)
    ).fetchone()


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        user = current_user()
        if user is None:
            if request.path.startswith("/api/") or request.path.startswith("/patients/"):
                return jsonify(error="Authentication required"), 401
            return redirect(url_for("home"))
        if not user["is_admin"] and not user["is_approved"]:
            session.clear()
            if request.path.startswith("/api/"):
                return jsonify(error="Your account is awaiting administrator approval."), 403
            return redirect(url_for("home"))
        g.current_doctor = user
        return fn(*args, **kwargs)
    return wrapper


def admin_required(fn):
    @wraps(fn)
    @login_required
    def wrapper(*args, **kwargs):
        if not g.current_doctor["is_admin"]:
            if request.path.startswith("/api/"):
                return jsonify(error="Administrator access required"), 403
            return redirect(url_for("home"))
        return fn(*args, **kwargs)
    return wrapper


@app.get("/")
def home():
    user = current_user()
    if user:
        if user["is_admin"]:
            return redirect(url_for("admin_page"))
        if not user["is_approved"]:
            session.clear()
            return render_template("login.html", pending_message="Your account is awaiting administrator approval.")
        return render_template("dashboard.html")
    return render_template("login.html")


@app.get("/signup")
def signup_page():
    if current_user():
        return redirect(url_for("home"))
    return render_template("signup.html")


@app.get("/admin")
@admin_required
def admin_page():
    return render_template("admin.html")


@app.get("/health")
def health():
    return jsonify(status="ok", service="MedGuard AI demo backend")


@app.post("/signup")
def signup():
    payload = request.get_json(silent=True) or {}
    username = payload.get("username", "")
    password = payload.get("password", "")
    confirm_password = payload.get("confirm_password", "")
    if not all(isinstance(value, str) for value in (username, password, confirm_password)):
        return jsonify(error="Please provide valid signup details."), 400
    username = username.strip()
    if len(username) < 3 or len(username) > 40 or not all(ch.isalnum() or ch in "_.-" for ch in username):
        return jsonify(error="Username must be 3–40 characters and use only letters, numbers, dots, dashes or underscores."), 400
    if len(password) < 12:
        return jsonify(error="Use a password with at least 12 characters."), 400
    if password != confirm_password:
        return jsonify(error="Passwords do not match."), 400
    try:
        cursor = db().execute(
            "INSERT INTO doctors (username, password_hash, is_admin, is_approved) VALUES (?, ?, 0, 0)",
            (username, generate_password_hash(password)),
        )
        db().commit()
    except sqlite3.IntegrityError:
        return jsonify(error="That username is already registered. Please choose another."), 409
    write_audit(cursor.lastrowid, None, "signup", "pending", "New doctor registered; waiting for administrator approval")
    return jsonify(message="Account created. An administrator must approve your account before you can sign in."), 201


@app.post("/login")
def login():
    payload = request.get_json(silent=True) or {}
    username, password = payload.get("username", ""), payload.get("password", "")
    if not isinstance(username, str) or not isinstance(password, str):
        return jsonify(error="Invalid username or password"), 401
    user = db().execute(
        "SELECT id, username, password_hash, is_admin, is_approved FROM doctors WHERE username=?", (username.strip(),)
    ).fetchone()
    if user is None or not check_password_hash(user["password_hash"], password):
        write_audit(None, None, "login", "denied", "Invalid login attempt")
        return jsonify(error="Invalid username or password"), 401
    if not user["is_admin"] and not user["is_approved"]:
        write_audit(user["id"], None, "login", "pending", "Sign-in blocked because administrator approval is pending")
        return jsonify(error="Your account is awaiting administrator approval."), 403
    session.clear()
    session.permanent = True
    session["doctor_id"] = user["id"]
    write_audit(user["id"], None, "login", "allowed", "Administrator login successful" if user["is_admin"] else "Doctor login successful")
    return jsonify(message="Login successful", user={"id": user["id"], "username": user["username"], "is_admin": bool(user["is_admin"])})


@app.post("/logout")
@login_required
def logout():
    user_id = g.current_doctor["id"]
    write_audit(user_id, None, "logout", "allowed", "User logged out")
    session.clear()
    return jsonify(message="Logged out")


@app.get("/api/me")
@login_required
def me():
    return jsonify(user={"id": g.current_doctor["id"], "username": g.current_doctor["username"], "is_admin": bool(g.current_doctor["is_admin"])}, doctor={"id": g.current_doctor["id"], "username": g.current_doctor["username"]})


@app.get("/api/patients")
@login_required
def assigned_patients():
    if g.current_doctor["is_admin"]:
        return jsonify(error="Use the admin patient list; admin accounts do not use the doctor dashboard."), 403
    rows = db().execute("""SELECT p.id, p.display_name,
        (SELECT v.heart_rate_bpm FROM vital_readings v WHERE v.patient_id=p.id ORDER BY v.id DESC LIMIT 1) AS heart_rate_bpm,
        (SELECT v.spo2_percent FROM vital_readings v WHERE v.patient_id=p.id ORDER BY v.id DESC LIMIT 1) AS spo2_percent,
        (SELECT v.temperature_c FROM vital_readings v WHERE v.patient_id=p.id ORDER BY v.id DESC LIMIT 1) AS temperature_c,
        (SELECT v.measured_at FROM vital_readings v WHERE v.patient_id=p.id ORDER BY v.id DESC LIMIT 1) AS measured_at
        FROM patients p JOIN assignments a ON a.patient_id=p.id
        WHERE a.doctor_id=? ORDER BY p.id""", (g.current_doctor["id"],)).fetchall()
    return jsonify(patients=[dict(r) for r in rows])


@app.get("/patients/<int:patient_id>/records")
@login_required
def patient_records(patient_id):
    if g.current_doctor["is_admin"]:
        return jsonify(error="Admin accounts manage assignments; use an approved doctor account to view clinical records."), 403
    doctor_id = g.current_doctor["id"]
    assignment = db().execute("SELECT 1 FROM assignments WHERE doctor_id=? AND patient_id=?", (doctor_id, patient_id)).fetchone()
    if assignment is None:
        write_audit(doctor_id, patient_id, "view_patient_records", "denied", "Doctor is not assigned to this patient")
        return jsonify(error="Access denied", alert="Unauthorized access attempt recorded"), 403
    patient = db().execute("SELECT id, display_name FROM patients WHERE id=?", (patient_id,)).fetchone()
    if patient is None:
        write_audit(doctor_id, patient_id, "view_patient_records", "denied", "Patient not found")
        return jsonify(error="Patient not found"), 404
    readings = db().execute("""SELECT id, heart_rate_bpm, spo2_percent, temperature_c, measured_at, source
        FROM vital_readings WHERE patient_id=? ORDER BY id DESC LIMIT 100""", (patient_id,)).fetchall()
    write_audit(doctor_id, patient_id, "view_patient_records", "allowed", "Assigned doctor viewed patient records")
    return jsonify(patient={"id": patient["id"], "display_name": patient["display_name"]}, readings=[dict(row) for row in readings])



@app.get("/api/thingspeak/config")
@login_required
def thingspeak_config():
    # Intentionally never return the read API key to the browser.
    configured = bool(THINGSPEAK_CHANNEL_ID)
    return jsonify(
        configured=configured,
        patient_id=THINGSPEAK_PATIENT_ID if configured else None,
        refresh_interval_seconds=20,
        field_mapping={"field1": "heart_rate_bpm", "field2": "spo2_percent", "field3": "temperature_c", "field4": "sequence_number", "field5": "health_status_code", "field6": "security_status_code", "field7": "sensor_quality_code", "field8": "network_status_code"},
    )


@app.post("/api/thingspeak/refresh")
@login_required
def thingspeak_refresh():
    if g.current_doctor["is_admin"]:
        return jsonify(error="Use an approved doctor account to view live patient readings."), 403
    patient_id = THINGSPEAK_PATIENT_ID
    doctor_id = g.current_doctor["id"]
    assignment = db().execute(
        "SELECT 1 FROM assignments WHERE doctor_id=? AND patient_id=?", (doctor_id, patient_id)
    ).fetchone()
    if assignment is None:
        write_audit(doctor_id, patient_id, "thingspeak_access", "denied", "Doctor is not assigned to the configured ThingSpeak patient")
        return jsonify(error="Access denied: this patient is not assigned to your account."), 403
    patient = db().execute("SELECT id, display_name FROM patients WHERE id=?", (patient_id,)).fetchone()
    if patient is None:
        return jsonify(error="Configured ThingSpeak patient does not exist. Create the patient in the admin panel first."), 404
    try:
        reading = fetch_thingspeak_latest()
    except RuntimeError as exc:
        write_audit(doctor_id, patient_id, "thingspeak_refresh", "error", str(exc))
        return jsonify(error=str(exc), configured=bool(THINGSPEAK_CHANNEL_ID)), 502

    # Save only a new timestamp so refresh polling does not duplicate the same sample.
    existing = db().execute(
        "SELECT id FROM vital_readings WHERE patient_id=? AND source='thingspeak' AND measured_at=? LIMIT 1",
        (patient_id, reading["measured_at"]),
    ).fetchone()
    if existing is None:
        db().execute(
            "INSERT INTO vital_readings (patient_id, heart_rate_bpm, spo2_percent, temperature_c, measured_at, source) VALUES (?, ?, ?, ?, ?, 'thingspeak')",
            (patient_id, reading["heart_rate_bpm"], reading["spo2_percent"], reading["temperature_c"], reading["measured_at"]),
        )
        db().commit()
    write_audit(doctor_id, patient_id, "thingspeak_refresh", "allowed", "Fetched latest ThingSpeak reading for assigned patient")
    return jsonify(patient={"id": patient["id"], "display_name": patient["display_name"]}, reading=reading, message="Latest ThingSpeak reading loaded.")


@app.get("/audit")
@login_required
def audit_log():
    rows = db().execute("""SELECT occurred_at, actor_doctor_id, patient_id, action, outcome, detail
        FROM audit_log WHERE actor_doctor_id=? ORDER BY id DESC LIMIT 100""", (g.current_doctor["id"],)).fetchall()
    return jsonify(events=[dict(row) for row in rows])


@app.get("/api/admin/summary")
@admin_required
def admin_summary():
    conn = db()
    return jsonify(
        pending_doctors=conn.execute("SELECT COUNT(*) FROM doctors WHERE is_admin=0 AND is_approved=0").fetchone()[0],
        approved_doctors=conn.execute("SELECT COUNT(*) FROM doctors WHERE is_admin=0 AND is_approved=1").fetchone()[0],
        patients=conn.execute("SELECT COUNT(*) FROM patients").fetchone()[0],
        assignments=conn.execute("SELECT COUNT(*) FROM assignments").fetchone()[0],
    )


@app.get("/api/admin/doctors")
@admin_required
def admin_doctors():
    rows = db().execute("""SELECT d.id, d.username, d.is_approved,
        (SELECT COUNT(*) FROM assignments a WHERE a.doctor_id=d.id) AS patient_count
        FROM doctors d WHERE d.is_admin=0 ORDER BY d.is_approved ASC, d.username COLLATE NOCASE""").fetchall()
    return jsonify(doctors=[dict(r) for r in rows])


@app.post("/api/admin/doctors/<int:doctor_id>/approval")
@admin_required
def set_doctor_approval(doctor_id):
    payload = request.get_json(silent=True) or {}
    approved = payload.get("approved")
    if not isinstance(approved, bool):
        return jsonify(error="approved must be true or false"), 400
    target = db().execute("SELECT id, username, is_admin FROM doctors WHERE id=?", (doctor_id,)).fetchone()
    if target is None or target["is_admin"]:
        return jsonify(error="Doctor account not found"), 404
    db().execute("UPDATE doctors SET is_approved=? WHERE id=?", (int(approved), doctor_id))
    if not approved:
        db().execute("DELETE FROM assignments WHERE doctor_id=?", (doctor_id,))
    db().commit()
    write_audit(g.current_doctor["id"], None, "doctor_approval", "allowed", f"Admin {'approved' if approved else 'revoked'} account {target['username']}; assignments {'cleared' if not approved else 'retained'}")
    return jsonify(message=f"Account {target['username']} {'approved' if approved else 'blocked'}.")


@app.get("/api/admin/patients")
@admin_required
def admin_patients():
    rows = db().execute("""SELECT p.id, p.display_name,
        GROUP_CONCAT(d.username, ', ') AS assigned_doctors
        FROM patients p LEFT JOIN assignments a ON a.patient_id=p.id
        LEFT JOIN doctors d ON d.id=a.doctor_id
        GROUP BY p.id, p.display_name ORDER BY p.id""").fetchall()
    return jsonify(patients=[dict(r) for r in rows])


@app.post("/api/admin/patients")
@admin_required
def create_patient():
    payload = request.get_json(silent=True) or {}
    name = payload.get("display_name", "")
    if not isinstance(name, str) or not 2 <= len(name.strip()) <= 80:
        return jsonify(error="Patient display name must be 2–80 characters."), 400
    cursor = db().execute("INSERT INTO patients (display_name) VALUES (?)", (name.strip(),))
    db().commit()
    write_audit(g.current_doctor["id"], cursor.lastrowid, "patient_created", "allowed", "Admin created a demo patient record")
    return jsonify(message="Demo patient created.", patient_id=cursor.lastrowid), 201


@app.post("/api/admin/assignments")
@admin_required
def create_assignment():
    payload = request.get_json(silent=True) or {}
    try:
        doctor_id, patient_id = int(payload.get("doctor_id")), int(payload.get("patient_id"))
    except (TypeError, ValueError):
        return jsonify(error="Choose a doctor and patient."), 400
    doctor = db().execute("SELECT id, username, is_admin, is_approved FROM doctors WHERE id=?", (doctor_id,)).fetchone()
    patient = db().execute("SELECT id, display_name FROM patients WHERE id=?", (patient_id,)).fetchone()
    if doctor is None or doctor["is_admin"] or not doctor["is_approved"]:
        return jsonify(error="Only an approved doctor account can be assigned patients."), 400
    if patient is None:
        return jsonify(error="Patient not found."), 404
    try:
        db().execute("INSERT INTO assignments (doctor_id, patient_id) VALUES (?, ?)", (doctor_id, patient_id))
        db().commit()
    except sqlite3.IntegrityError:
        return jsonify(error="This patient is already assigned to that doctor."), 409
    write_audit(g.current_doctor["id"], patient_id, "patient_assignment", "allowed", f"Admin assigned patient {patient_id} to doctor {doctor['username']}")
    return jsonify(message=f"{patient['display_name']} assigned to {doctor['username']}.")


@app.delete("/api/admin/assignments")
@admin_required
def delete_assignment():
    payload = request.get_json(silent=True) or {}
    try:
        doctor_id, patient_id = int(payload.get("doctor_id")), int(payload.get("patient_id"))
    except (TypeError, ValueError):
        return jsonify(error="Choose a doctor and patient."), 400
    doctor = db().execute("SELECT username FROM doctors WHERE id=? AND is_admin=0", (doctor_id,)).fetchone()
    if not doctor:
        return jsonify(error="Doctor not found."), 404
    cursor = db().execute("DELETE FROM assignments WHERE doctor_id=? AND patient_id=?", (doctor_id, patient_id))
    db().commit()
    if not cursor.rowcount:
        return jsonify(error="That assignment does not exist."), 404
    write_audit(g.current_doctor["id"], patient_id, "patient_unassignment", "allowed", f"Admin unassigned patient {patient_id} from doctor {doctor['username']}")
    return jsonify(message="Patient assignment removed.")


@app.get("/api/admin/audit")
@admin_required
def admin_audit():
    rows = db().execute("""SELECT a.occurred_at, a.actor_doctor_id, d.username AS actor_username,
        a.patient_id, a.action, a.outcome, a.detail FROM audit_log a
        LEFT JOIN doctors d ON d.id=a.actor_doctor_id ORDER BY a.id DESC LIMIT 50""").fetchall()
    return jsonify(events=[dict(r) for r in rows])


init_db()
seed_demo_data()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "5000")), debug=False)
