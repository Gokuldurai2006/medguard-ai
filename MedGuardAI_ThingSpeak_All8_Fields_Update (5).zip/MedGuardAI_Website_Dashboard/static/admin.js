const $ = (id) => document.getElementById(id);
let doctorsCache = [], patientsCache = [];
function escapeHtml(value) { return String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch])); }
function fmtTime(value) { const d = new Date(value); return Number.isNaN(d.getTime()) ? value : d.toLocaleString(); }
function notice(message, isError=false) { const el=$('admin-notice'); el.textContent=message; el.classList.remove('hidden'); el.style.background=isError?'#fff0ee':'#eaf8f2'; el.style.borderColor=isError?'#f3ceca':'#ccefe0'; el.style.color=isError?'#a13d37':'#18744f'; }
async function api(url, options={}) {
  const response = await fetch(url, {credentials:'same-origin', ...options, headers:{'Content-Type':'application/json', ...(options.headers||{})}});
  const data = await response.json().catch(()=>({}));
  if (response.status===401) { window.location.href='/'; throw new Error('Please sign in again.'); }
  if (!response.ok) throw new Error(data.error || 'Request failed');
  return data;
}
async function loadSummary() {
  const s=await api('/api/admin/summary');
  $('pending-count').textContent=s.pending_doctors; $('approved-count').textContent=s.approved_doctors;
  $('patient-count').textContent=s.patients; $('assignment-count').textContent=s.assignments;
}
async function loadDoctors() {
  const data=await api('/api/admin/doctors'); doctorsCache=data.doctors||[];
  $('doctor-table').innerHTML=doctorsCache.length ? doctorsCache.map(d=>`<tr>
    <td><div class="patient-name"><span class="patient-avatar">${escapeHtml(d.username.slice(0,2).toUpperCase())}</span><span>${escapeHtml(d.username)}<small class="patient-id">Doctor account #${d.id}</small></span></div></td>
    <td><span class="admin-status ${d.is_approved?'approved':'pending'}">${d.is_approved?'Approved':'Pending approval'}</span></td>
    <td>${d.patient_count}</td><td>${d.is_approved?`<button class="open-btn revoke-btn" data-doctor="${d.id}" data-approved="false">Block / revoke</button>`:`<button class="open-btn approve-btn" data-doctor="${d.id}" data-approved="true">Approve</button>`}</td>
  </tr>`).join('') : '<tr><td colspan="4" class="empty-state">No doctor accounts yet.</td></tr>';
  document.querySelectorAll('[data-doctor]').forEach(btn=>btn.addEventListener('click', async()=>{
    const id=btn.dataset.doctor, approved=btn.dataset.approved==='true';
    try { const result=await api(`/api/admin/doctors/${id}/approval`,{method:'POST',body:JSON.stringify({approved})}); notice(result.message); await reloadAll(); }
    catch(e){notice(e.message,true);}
  }));
  const approved=doctorsCache.filter(d=>d.is_approved);
  $('assign-doctor').innerHTML='<option value="">Select doctor</option>'+approved.map(d=>`<option value="${d.id}">${escapeHtml(d.username)}</option>`).join('');
}
async function loadPatients() {
  const data=await api('/api/admin/patients'); patientsCache=data.patients||[];
  $('assign-patient').innerHTML='<option value="">Select patient</option>'+patientsCache.map(p=>`<option value="${p.id}">#${p.id} — ${escapeHtml(p.display_name)}</option>`).join('');
}
async function loadAudit() {
  const data=await api('/api/admin/audit'); const events=data.events||[];
  $('admin-audit-list').innerHTML=events.length?events.slice(0,12).map(e=>{
    const denied=['denied','pending'].includes(e.outcome);
    return `<div class="activity-item"><div class="activity-symbol ${denied?'denied':''}">${denied?'!':'✓'}</div><div class="activity-copy"><b>${escapeHtml((e.action||'event').replaceAll('_',' '))}</b><small>${escapeHtml(e.detail)} · Actor: ${escapeHtml(e.actor_username||'system')}${e.patient_id?' · Patient '+escapeHtml(e.patient_id):''}</small></div><span class="outcome-pill ${denied?'denied':''}">${escapeHtml(e.outcome)}</span><span class="event-time">${escapeHtml(fmtTime(e.occurred_at))}</span></div>`;
  }).join(''):'<div class="empty-state">No audit events yet.</div>';
}
async function reloadAll() { try { await Promise.all([loadSummary(),loadDoctors(),loadPatients(),loadAudit()]); } catch(e) { notice(e.message,true); } }
$('assignment-form').addEventListener('submit',async e=>{
  e.preventDefault(); try { const result=await api('/api/admin/assignments',{method:'POST',body:JSON.stringify({doctor_id:$('assign-doctor').value,patient_id:$('assign-patient').value})}); notice(result.message); await reloadAll(); }
  catch(err){notice(err.message,true);}
});
$('patient-form').addEventListener('submit',async e=>{
  e.preventDefault(); try { const result=await api('/api/admin/patients',{method:'POST',body:JSON.stringify({display_name:$('patient-name').value})}); notice(`${result.message} Patient ID: ${result.patient_id}`); $('patient-name').value=''; await reloadAll(); }
  catch(err){notice(err.message,true);}
});
$('refresh-btn').addEventListener('click',reloadAll); $('audit-refresh-btn').addEventListener('click',loadAudit);
$('logout-btn').addEventListener('click',async()=>{try{await api('/logout',{method:'POST'});window.location.href='/';}catch(e){notice(e.message,true);}});
(async()=>{try{const me=await api('/api/me');if(!me.user?.is_admin){window.location.href='/';return;}$('admin-name').textContent=me.user.username;await reloadAll();}catch(e){notice(e.message,true);}})();
