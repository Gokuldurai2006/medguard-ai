const $ = (id) => document.getElementById(id);
let patientsCache = [];
let thingSpeakConfig = {configured:false, patient_id:null, refresh_interval_seconds:20};
let thingSpeakTimer = null;

function fmtTime(value) {
  if (!value) return 'No timestamp';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString();
}
function initials(name) {
  return (name || 'Patient').split(/\s+/).slice(-2).map(p => p[0]).join('').toUpperCase();
}
function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
}
function showNotice(message) {
  const el = $('notice');
  el.textContent = message;
  el.classList.remove('hidden');
}
async function api(url, options={}) {
  const response = await fetch(url, {credentials:'same-origin', ...options});
  const data = await response.json().catch(() => ({}));
  if (response.status === 401) { window.location.href = '/'; throw new Error('Please sign in again.'); }
  if (!response.ok) throw new Error(data.error || 'Request failed');
  return data;
}
function renderPatients() {
  $('patient-count').textContent = patientsCache.length;
  $('stat-patients').textContent = patientsCache.length;
  if (!patientsCache.length) {
    $('patient-table').innerHTML = '<tr><td colspan="5" class="empty-state">No patients are assigned to this account.</td></tr>';
    return;
  }
  $('patient-table').innerHTML = patientsCache.map(p => `
    <tr>
      <td><div class="patient-name"><span class="patient-avatar">${escapeHtml(initials(p.display_name))}</span><span>${escapeHtml(p.display_name)}<small class="patient-id">Patient ID: ${escapeHtml(p.id)}</small></span></div></td>
      <td><span class="reading">${p.heart_rate_bpm ?? '—'}</span> <span class="unit">BPM</span></td>
      <td><span class="reading">${p.spo2_percent ?? '—'}%</span></td>
      <td><span class="reading">${p.temperature_c ?? '—'}°C</span></td>
      <td><button class="open-btn" data-patient="${escapeHtml(p.id)}">View records</button></td>
    </tr>`).join('');
  document.querySelectorAll('[data-patient]').forEach(button => button.addEventListener('click', () => viewPatient(button.dataset.patient)));
  const first = patientsCache[0];
  if (first) {
    $('stat-hr').textContent = first.heart_rate_bpm ?? '—';
    $('stat-spo2').textContent = first.spo2_percent ?? '—';
  }
}
async function viewPatient(id) {
  try {
    const data = await api(`/patients/${encodeURIComponent(id)}/records`);
    const latest = data.readings[0];
    showNotice(`Access granted: ${data.patient.display_name} (ID ${data.patient.id}). ${data.readings.length} record(s) returned. Source: ${latest?.source || 'unknown'}.`);
  } catch (error) {
    showNotice(`Security event: ${error.message}`);
  }
}
async function loadAudit() {
  try {
    const data = await api('/audit');
    const events = data.events || [];
    if (!events.length) {
      $('activity-list').innerHTML = '<div class="empty-state">No security activity recorded yet.</div>';
      return;
    }
    $('activity-list').innerHTML = events.slice(0,4).map(event => {
      const denied = event.outcome === 'denied';
      return `<div class="activity-item">
        <div class="activity-symbol ${denied?'denied':''}">${denied?'!':'✓'}</div>
        <div class="activity-copy"><b>${escapeHtml(event.action.replaceAll('_',' '))}</b><small>${escapeHtml(event.detail)}${event.patient_id ? ' · Patient '+escapeHtml(event.patient_id):''}</small></div>
        <span class="outcome-pill ${denied?'denied':''}">${escapeHtml(event.outcome)}</span>
        <span class="event-time">${escapeHtml(fmtTime(event.occurred_at))}</span>
      </div>`;
    }).join('');
  } catch (error) {
    $('activity-list').innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`;
  }
}
function setThingSpeakStatus(message, kind='') {
  const status = $('thingspeak-status');
  status.textContent = message;
  const old = document.getElementById('thingspeak-badge');
  if (old) old.remove();
  const badge = document.createElement('span');
  badge.id = 'thingspeak-badge';
  badge.className = `integration-badge ${kind}`;
  badge.textContent = kind === 'connected' ? 'Connected' : kind === 'error' ? 'Issue' : (thingSpeakConfig.configured ? 'Ready' : 'Setup needed');
  const row = document.querySelector('.thingspeak-row');
  if (row) row.appendChild(badge);
}
async function refreshThingSpeak(showMessage=true) {
  if (!thingSpeakConfig.configured) {
    setThingSpeakStatus('Not configured yet. Add your channel settings in the VS Code terminal.', 'error');
    return;
  }
  const patientId = Number(thingSpeakConfig.patient_id);
  const assigned = patientsCache.some(patient => Number(patient.id) === patientId);
  if (!assigned) {
    setThingSpeakStatus(`Channel is mapped to Patient ${patientId}; this doctor is not assigned to that patient.`, 'error');
    return;
  }
  const button = $('thingspeak-refresh');
  if (button) { button.disabled = true; button.textContent = 'Loading…'; }
  try {
    const data = await api('/api/thingspeak/refresh', {method:'POST'});
    const reading = data.reading;
    $('ts-hr').textContent = reading.heart_rate_bpm;
    $('ts-spo2').textContent = reading.spo2_percent;
    $('ts-temp').textContent = reading.temperature_c;
    $('ts-sequence').textContent = reading.sequence_number ?? 'Unknown';
    $('ts-health').textContent = `${reading.health_status_label ?? 'Unknown'}${reading.health_status_code === null || reading.health_status_code === undefined ? '' : ` (code ${reading.health_status_code})`}`;
    $('ts-security').textContent = `${reading.security_status_label ?? 'Unknown'}${reading.security_status_code === null || reading.security_status_code === undefined ? '' : ` (code ${reading.security_status_code})`}`;
    $('ts-sensor').textContent = `${reading.sensor_quality_label ?? 'Unknown'}${reading.sensor_quality_code === null || reading.sensor_quality_code === undefined ? '' : ` (code ${reading.sensor_quality_code})`}`;
    $('ts-network').textContent = `${reading.network_status_label ?? 'Unknown'}${reading.network_status_code === null || reading.network_status_code === undefined ? '' : ` (code ${reading.network_status_code})`}`;
    $('thingspeak-last-updated').textContent = `Measured: ${fmtTime(reading.measured_at)} · Saved to patient records`;
    setThingSpeakStatus(`Connected to ThingSpeak channel for ${data.patient.display_name} (ID ${data.patient.id}).`, 'connected');
    // Refresh the assigned-patient table so the newly fetched sample appears there too.
    const latest = await api('/api/patients');
    patientsCache = latest.patients || [];
    renderPatients();
    if (showMessage) showNotice('ThingSpeak reading refreshed successfully.');
  } catch (error) {
    setThingSpeakStatus(error.message, 'error');
    if (showMessage) showNotice(`ThingSpeak: ${error.message}`);
  } finally {
    if (button) { button.disabled = false; button.textContent = 'Refresh'; }
  }
}
async function loadThingSpeakConfig() {
  try {
    thingSpeakConfig = await api('/api/thingspeak/config');
    if (!thingSpeakConfig.configured) {
      setThingSpeakStatus('Not configured. Set THINGSPEAK_CHANNEL_ID in the server terminal.', 'error');
      $('thingspeak-last-updated').textContent = 'API keys stay on the server and are never sent to this page.';
      return;
    }
    setThingSpeakStatus(`Configured for demo Patient ${thingSpeakConfig.patient_id}.`, '');
    await refreshThingSpeak(false);
    if (thingSpeakTimer) clearInterval(thingSpeakTimer);
    thingSpeakTimer = setInterval(() => refreshThingSpeak(false), Math.max(20, Number(thingSpeakConfig.refresh_interval_seconds) || 20) * 1000);
  } catch (error) {
    setThingSpeakStatus(error.message, 'error');
  }
}
async function init() {
  try {
    const me = await api('/api/me');
    $('doctor-name').textContent = me.doctor.username;
    const data = await api('/api/patients');
    patientsCache = data.patients || [];
    renderPatients();
    $('updated-at').textContent = new Date().toLocaleTimeString();
    await loadAudit();
    await loadThingSpeakConfig();
  } catch (error) {
    showNotice(error.message);
  }
}
document.querySelectorAll('[data-view]').forEach(button => button.addEventListener('click', () => {
  const view = button.dataset.view;
  document.querySelectorAll('.nav-item').forEach(item => item.classList.toggle('active', item.dataset.view === view));
  const titles = {overview:'Patient overview', patients:'My patients', security:'Security activity'};
  $('page-title').textContent = titles[view] || 'Patient overview';
  $('crumb').textContent = view.charAt(0).toUpperCase()+view.slice(1);
  if (view === 'patients') document.querySelector('.patient-panel').scrollIntoView({behavior:'smooth',block:'start'});
  if (view === 'security') document.querySelector('.activity-panel').scrollIntoView({behavior:'smooth',block:'start'});
  if (view === 'overview') window.scrollTo({top:0,behavior:'smooth'});
}));
$('thingspeak-refresh').addEventListener('click', () => refreshThingSpeak(true));
$('logout-btn').addEventListener('click', async () => {
  try { await api('/logout', {method:'POST'}); window.location.href='/'; }
  catch (error) { showNotice(error.message); }
});
init();
